package com.pennant.shoppingcart.models;

public class CustomerModel {
	private Integer cust_Id;
	private String cust_Name;
	private String cust_Mobile;
	private String cust_Location;
	private String cust_UserName;
	private String cust_PassWord;

	public Integer getCust_Id() {
		return cust_Id;
	}

	public void setCust_Id(Integer cust_Id) {
		this.cust_Id = cust_Id;
	}

	public String getCust_Name() {
		return cust_Name;
	}

	public void setCust_Name(String cust_Name) {
		this.cust_Name = cust_Name;
	}

	public String getCust_Mobile() {
		return cust_Mobile;
	}

	public void setCust_Mobile(String cust_Mobile) {
		this.cust_Mobile = cust_Mobile;
	}

	public String getCust_Location() {
		return cust_Location;
	}

	public void setCust_Location(String cust_Location) {
		this.cust_Location = cust_Location;
	}

	public String getCust_UserName() {
		return cust_UserName;
	}

	public void setCust_UserName(String cust_UserName) {
		this.cust_UserName = cust_UserName;
	}

	public String getCust_PassWord() {
		return cust_PassWord;
	}

	public void setCust_PassWord(String cust_PassWord) {
		this.cust_PassWord = cust_PassWord;
	}

}
