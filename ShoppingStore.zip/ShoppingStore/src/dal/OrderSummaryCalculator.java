package dal;

import java.math.BigDecimal;

public class OrderSummaryCalculator {
	public static BigDecimal[] calculateCharges(BigDecimal subtotal) {
		BigDecimal gstRate = new BigDecimal("0.18"); // GST rate is 18%
		BigDecimal shippingRate = new BigDecimal("0.02"); // Shipping rate is 2%

		BigDecimal gstCharge = subtotal.multiply(gstRate);
		BigDecimal shippingCharge = subtotal.multiply(shippingRate);

		BigDecimal total = subtotal.add(gstCharge).add(shippingCharge);

		return new BigDecimal[] { gstCharge, shippingCharge, total };
	}
}
