package controller;

import java.io.IOException;
import java.math.BigDecimal;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dal.OrderSummaryCalculator;

@SuppressWarnings("serial")
@WebServlet("/CalculateOrderSummary")
public class CalculateOrderSummaryServlet extends HttpServlet {
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// Retrieve subtotal from request parameter (assuming it's passed from previous step)
		BigDecimal subtotal = new BigDecimal(request.getParameter("subtotal"));

		// Calculate charges using OrderSummaryCalculator
		BigDecimal[] charges = OrderSummaryCalculator.calculateCharges(subtotal);

		// Set attributes for GST charge, shipping charge, and total
		request.setAttribute("gstCharge", charges[0]);
		request.setAttribute("shippingCharge", charges[1]);
		request.setAttribute("total", charges[2]);

		// Forward to JSP for display
		request.getRequestDispatcher("order_summary.jsp").forward(request, response);
	}
}
