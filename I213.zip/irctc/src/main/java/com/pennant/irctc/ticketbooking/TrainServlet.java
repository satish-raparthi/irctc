package com.pennant.irctc.ticketbooking;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.json.JSONArray;
import org.json.JSONObject;

import JDBCUTILITIES.JdbcUtil;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class TrainServlet
 */
@WebServlet(urlPatterns = { "/gettrains" }, loadOnStartup = 1, asyncSupported = true)
public class TrainServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public TrainServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
		response.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
		response.addHeader("Access-Control-Allow-Origin", "*");
		String from = request.getParameter("from");
		String to = request.getParameter("to");
		Connection con = null;
		PrintWriter out = response.getWriter();
		response.setContentType("application/json");
		try {
			con = JdbcUtil.getConnection();
			PreparedStatement st = con.prepareStatement("select * from i213_trains where train_no in(select fos.train_no from i213_trainstations fos,i213_trainstations tos where fos.station_id=? and tos.station_id=? and tos.train_no=fos.train_no and fos.trst_index<tos.trst_index)");
			st.setString(1, from);
			st.setString(2, to);
			ResultSet rs = st.executeQuery();
			String train_no, train_name;
			JSONObject train_data = new JSONObject();
			JSONArray train_no_arr = new JSONArray();
			JSONArray train_name_arr = new JSONArray();
			while (rs.next()) {
				train_no = rs.getString("train_no");
				train_name = rs.getString("train_name");
				train_no_arr.put(train_no.trim());
				train_name_arr.put(train_name.trim());
			}
			train_data.put("train_nos", train_no_arr);
			train_data.put("train_names", train_name_arr);
			out.println(train_data);
			JdbcUtil.closeConnections(con, st, rs);
			out.close();
		} catch (SQLException e) {
			// TODO: handle exception
		}
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		doPost(request, response);
	}
}