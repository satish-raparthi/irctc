package com.pennant.irctc.ticketbooking;

import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import JDBCUTILITIES.JdbcUtil;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class LoginValidation extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private Connection con;
	private ResultSet rs;
	private String dbpswd;
	private RequestDispatcher lprd;
	private RequestDispatcher hmprd;
	private HttpSession hs;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setHeader("Access-Control-Allow-Methods", "GET, POST, PUT, DELETE, OPTIONS");
		response.setHeader("Access-Control-Allow-Headers", "Content-Type, Authorization");
		response.addHeader("Access-Control-Allow-Origin", "*");
		hs = request.getSession(true);
		String uname = request.getParameter("username");
		String pswd = request.getParameter("password");
		con = JdbcUtil.getConnection();
		try {
			PreparedStatement psmt = con.prepareStatement("select pswd from i213_irctcusers where userid=?");
			psmt.setString(1, uname);
			rs = psmt.executeQuery();
			lprd = request.getRequestDispatcher("./loginpage.html");
			hmprd = request.getRequestDispatcher("./home.html");
			if (rs.next()) {
				dbpswd = rs.getString("pswd");
				if (dbpswd.equals(pswd)) {
					hmprd.forward(request, response);
					hs.setAttribute("LoggedIn", "yes");
				} else {
					lprd.forward(request, response);
				}
			} else {
				lprd.forward(request, response);

			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}

}
