package com.pennant.irctc.ticketbooking;

import java.io.IOException;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public class Authenticator extends HttpFilter implements Filter {

	private static final long serialVersionUID = 1L;

	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		// TODO Auto-generated method stub
		// place your code here
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse res = (HttpServletResponse) response;
		HttpSession hs = req.getSession(true);
		RequestDispatcher rd = req.getRequestDispatcher("loginpage.html");
		String status = (String) hs.getAttribute("LoggedIn");
		if (status == null || status.equals("no")) {
			rd.forward(req, res);
		}
		// pass the request along the filter chain
		else {
			chain.doFilter(request, response);
			System.out.println(hs.getAttribute("LoggedIn"));
		}
	}

}
