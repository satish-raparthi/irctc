$("document").ready(function(){
    let temp=$(".hyperLinks");

    $("#signUpButton").on({
        "click":function(){
            if($("#userConfirmPass").length>0){
                return;
            }
            $(".heading").children()[0].innerText="Sign Up Form";
            $("#signUpButton").css("background-color","bisque");
            $("#loginButton").css("background-color","white");
            $(".mainButton").children()[0].innerText="Sign Up";
            let cpassObj=$("<input>");
            cpassObj.attr({"type":"password","placeholder":"Confirm Password","name":"userConfirmPass","id":"userConfirmPass"});
            $(".inputFields").append(cpassObj);
            $(".hyperLinks").remove();
        }
    }),
    $("#loginButton").on({
        "click":function(){
            $(".child").append(temp);
            $("#userConfirmPass").remove();
            $(".heading").children()[0].innerText="Login Form";
            $("#signUpButton").css("background-color","white");
            $("#loginButton").css("background-color","bisque");
            $(".mainButton").children()[0].innerText="Log In";
        }
    })
})