package com.pennant.irctc.mvc;

public class TrainModel {
	private String train_no;
	private String Train_name;

	public String getTrain_no() {
		return train_no;
	}

	public void setTrain_no(String train_no) {
		this.train_no = train_no;
	}

	public String getTrain_name() {
		return Train_name;
	}

	public void setTrain_name(String train_name) {
		Train_name = train_name;
	}

}
