package com.pennant.irctc.mvc;

import java.util.ArrayList;

public class PassengerListModel extends ArrayList<PassengerModel> {
	private static final long serialVersionUID = 7733460832543729891L;
}
